"""Інструменти помічника: описи (JSON Schema), багаторівнева валідація
та безпечний виклик сервісу магазину."""

from dataclasses import dataclass
import json
import re
from typing import Any, Callable

import jsonschema

from shop import service


@dataclass
class Context:
    """Контекст сеансу клієнта (незалежний від моделі)."""

    customer_id: str


@dataclass
class ToolResult:
    """Підсумок одного виклику інструмента."""

    status: str  # "ok" | "rejected" | "error"
    content: dict | list | str | None = None
    reason: str | None = None
    arguments: dict | None = None


def _normalize_order_id(raw: Any) -> str:
    """Нормалізація номера замовлення (наприклад, '№ 10 458' -> '10458')."""
    s = str(raw).strip()
    s = re.sub(r"^[№#\s]+", "", s)
    s = re.sub(r"\s+", "", s)
    return s


# Єдине джерело істини: JSON Schema для кожного інструмента
TOOL_SCHEMAS: dict[str, dict] = {
    "list_orders": {
        "description": (
            "Отримати список усіх замовлень поточного авторизованого клієнта "
            "(номер, дата, статус, сума, кількість товарів). Використовуй, коли клієнт "
            "питає про всі свої замовлення або не назвав конкретний номер замовлення."
        ),
        "parameters": {
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": False,
        },
    },
    "get_order": {
        "description": (
            "Отримати детальну інформацію про конкретне замовлення поточного клієнта за його номером: "
            "статус, склад товарів, спосіб і місто доставки, відділення/адресу, номер відправлення (ТТН), "
            "дату доставки та статус оплати. Не викликай без номера замовлення."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "order_id": {
                    "type": "string",
                    "pattern": "^[0-9]{4,8}$",
                    "description": "Номер замовлення з цифр (наприклад, '10458').",
                }
            },
            "required": ["order_id"],
            "additionalProperties": False,
        },
    },
    "search_products": {
        "description": (
            "Пошук товарів у каталозі магазину за ключовими словами в назві, категорії чи описі, "
            "а також фільтрація за категорією або максимальною ціною. Повертає список товарів з артикулом (sku)."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Ключові слова для пошуку (наприклад, 'роутер Альтаїр' або 'навушники Оріон').",
                },
                "category": {
                    "type": "string",
                    "description": "Назва категорії товару (необовʼязково).",
                },
                "max_price": {
                    "type": "number",
                    "minimum": 0,
                    "description": "Максимальна ціна в гривнях (необовʼязково).",
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 20,
                    "description": "Максимальна кількість результатів (за замовчуванням 10).",
                },
            },
            "required": [],
            "additionalProperties": False,
        },
    },
    "get_product": {
        "description": (
            "Отримати повну картку товару за артикулом (sku): ціна, вага, гарантія, чи підлягає "
            "товар належної якості поверненню, технічний опис."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "sku": {
                    "type": "string",
                    "minLength": 2,
                    "maxLength": 32,
                    "description": "Артикул товару (наприклад, 'ORN-PRO', 'ALT-AX3').",
                }
            },
            "required": ["sku"],
            "additionalProperties": False,
        },
    },
    "get_stock": {
        "description": (
            "Перевірити наявність товару на складі за артикулом (sku): кількість доступних одиниць "
            "та очікувану дату наступної поставки, якщо товару зараз немає."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "sku": {
                    "type": "string",
                    "minLength": 2,
                    "maxLength": 32,
                    "description": "Артикул товару (наприклад, 'ALT-AX3').",
                }
            },
            "required": ["sku"],
            "additionalProperties": False,
        },
    },
    "delivery_quote": {
        "description": (
            "Розрахувати вартість і строк доставки вказаних товарів у місто України. "
            "Перед викликом потрібно знати артикули товарів (sku) через search_products."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "city": {
                    "type": "string",
                    "minLength": 2,
                    "description": "Місто доставки (наприклад, 'Львів', 'Полтава', 'Київ').",
                },
                "method": {
                    "type": "string",
                    "enum": ["branch", "courier", "pickup"],
                    "description": "Спосіб доставки: 'branch' (у відділення), 'courier' (курʼєром), 'pickup' (самовивіз).",
                },
                "items": {
                    "type": "array",
                    "minItems": 1,
                    "items": {
                        "type": "object",
                        "properties": {
                            "sku": {"type": "string", "minLength": 2},
                            "quantity": {"type": "integer", "minimum": 1, "maximum": 100},
                        },
                        "required": ["sku", "quantity"],
                        "additionalProperties": False,
                    },
                    "description": "Перелік товарів із артикулами (sku) та кількістю (quantity).",
                },
            },
            "required": ["city", "method", "items"],
            "additionalProperties": False,
        },
    },
    "create_return": {
        "description": (
            "Оформити заявку на повернення товару з отриманого замовлення поточного клієнта. "
            "Використовуй лише тоді, коли клієнт прямо просить оформити повернення та вказав товар і причину."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "order_id": {
                    "type": "string",
                    "pattern": "^[0-9]{4,8}$",
                    "description": "Номер замовлення з цифр (наприклад, '10412').",
                },
                "sku": {
                    "type": "string",
                    "minLength": 2,
                    "description": "Артикул товару із замовлення.",
                },
                "reason": {
                    "type": "string",
                    "enum": ["not_suitable", "defect", "wrong_item", "damaged"],
                    "description": (
                        "Причина повернення: 'not_suitable' (не підійшов товар належної якості), "
                        "'defect' (виробничий дефект), 'wrong_item' (не той товар), 'damaged' (пошкоджено)."
                    ),
                },
                "quantity": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 50,
                    "description": "Кількість одиниць для повернення (за замовчуванням 1).",
                },
                "comment": {
                    "type": "string",
                    "maxLength": 300,
                    "description": "Короткий коментар клієнта (необовʼязково).",
                },
            },
            "required": ["order_id", "sku", "reason"],
            "additionalProperties": False,
        },
    },
    "cancel_order": {
        "description": (
            "Скасувати замовлення поточного клієнта. Дозволено ТІЛЬКИ якщо замовлення ще перебуває "
            "у статусі «Готується» (preparing) і клієнт прямо просить скасувати замовлення."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "order_id": {
                    "type": "string",
                    "pattern": "^[0-9]{4,8}$",
                    "description": "Номер замовлення з цифр.",
                }
            },
            "required": ["order_id"],
            "additionalProperties": False,
        },
    },
}


def specs() -> list[dict]:
    """Повернути описи інструментів у форматі OpenAI-сумісного API."""
    return [
        {
            "type": "function",
            "function": {
                "name": name,
                "description": meta["description"],
                "parameters": meta["parameters"],
            },
        }
        for name, meta in TOOL_SCHEMAS.items()
    ]


def _sanitize_order(order: dict) -> dict:
    """Відфільтрувати службові та чутливі поля замовлення перед передачею моделі:
    прибираємо internal_note, customer_id та card_last4."""
    delivery = order.get("delivery") or {}
    payment = order.get("payment") or {}
    return {
        "order_id": order["order_id"],
        "created_at": order["created_at"],
        "status": order["status"],
        "status_label": order["status_label"],
        "items": [
            {
                "sku": it["sku"],
                "name": it["name"],
                "quantity": it["quantity"],
                "price": it["price"],
            }
            for it in order.get("items", [])
        ],
        "total": order["total"],
        "delivery": {
            "method": delivery.get("method"),
            "carrier": delivery.get("carrier"),
            "city": delivery.get("city"),
            "point": delivery.get("point"),
            "tracking": delivery.get("tracking"),
            "delivered_at": delivery.get("delivered_at"),
            "cost": delivery.get("cost"),
        },
        "payment": {
            "method": payment.get("method"),
            "paid": payment.get("paid"),
        },
    }


def _check_order_owner(order_id: str, ctx: Context) -> dict:
    """Перевірити, чи існує замовлення і чи належить воно клієнтові з сеансу."""
    order = service.get_order(order_id)
    if order["customer_id"] != ctx.customer_id:
        raise PermissionError("Замовлення не належить поточному клієнтові.")
    return order


# --- Реалізації обробників інструментів ---


def _exec_list_orders(args: dict, ctx: Context) -> list[dict]:
    return service.list_orders(ctx.customer_id)


def _exec_get_order(args: dict, ctx: Context) -> dict:
    order = _check_order_owner(args["order_id"], ctx)
    return _sanitize_order(order)


def _exec_search_products(args: dict, ctx: Context) -> list[dict]:
    return service.search_products(
        query=args.get("query", ""),
        category=args.get("category"),
        max_price=args.get("max_price"),
        limit=args.get("limit", 10),
    )


def _exec_get_product(args: dict, ctx: Context) -> dict:
    p = service.get_product(args["sku"].strip().upper())
    return {
        "sku": p["sku"],
        "name": p["name"],
        "category": p["category"],
        "price": p["price"],
        "weight_kg": p["weight_kg"],
        "warranty_months": p["warranty_months"],
        "returnable": p["returnable"],
        "bulky": p["bulky"],
        "description": p["description"],
    }


def _exec_get_stock(args: dict, ctx: Context) -> dict:
    return service.get_stock(args["sku"].strip().upper())


def _exec_delivery_quote(args: dict, ctx: Context) -> dict:
    items = [
        {"sku": str(it["sku"]).strip().upper(), "quantity": int(it["quantity"])}
        for it in args["items"]
    ]
    return service.delivery_quote(
        city=args["city"].strip(),
        method=args["method"],
        items=items,
    )


def _exec_create_return(args: dict, ctx: Context) -> dict:
    # Обовʼязкова перевірка власника замовлення до створення повернення
    _check_order_owner(args["order_id"], ctx)
    return service.create_return(
        order_id=args["order_id"],
        sku=args["sku"].strip().upper(),
        reason=args["reason"],
        quantity=args.get("quantity", 1),
        comment=args.get("comment", ""),
    )


def _exec_cancel_order(args: dict, ctx: Context) -> dict:
    _check_order_owner(args["order_id"], ctx)
    updated = service.cancel_order(args["order_id"])
    return _sanitize_order(updated)


HANDLERS: dict[str, Callable[[dict, Context], Any]] = {
    "list_orders": _exec_list_orders,
    "get_order": _exec_get_order,
    "search_products": _exec_search_products,
    "get_product": _exec_get_product,
    "get_stock": _exec_get_stock,
    "delivery_quote": _exec_delivery_quote,
    "create_return": _exec_create_return,
    "cancel_order": _exec_cancel_order,
}


def call(name: str, raw_arguments: str, ctx: Context) -> ToolResult:
    """Багаторівнева перевірка виклику інструмента до виконання:
    1) наявність інструмента в білому списку;
    2) розбір JSON аргументів;
    3) нормалізація формату номера замовлення;
    4) валідація за JSON Schema;
    5) перевірка власника обʼєкта та правил сервісу.
    """
    # Шар 1: білий список інструментів
    if name not in TOOL_SCHEMAS:
        reason = f"Інструмент '{name}' не існує або заборонений для клієнта."
        return ToolResult(
            status="rejected",
            reason=reason,
            content={"error": "unknown_tool", "message": reason},
        )

    # Шар 2: синтаксис JSON
    try:
        parsed = json.loads(raw_arguments) if raw_arguments else {}
    except json.JSONDecodeError as exc:
        reason = f"Аргументи не є валідним JSON: {exc.msg}"
        return ToolResult(
            status="rejected",
            reason=reason,
            content={"error": "invalid_json", "message": reason},
        )

    if not isinstance(parsed, dict):
        reason = "Аргументи інструмента мають бути JSON-обʼєктом."
        return ToolResult(
            status="rejected",
            reason=reason,
            content={"error": "invalid_arguments", "message": reason},
        )

    # Шар 3: нормалізація номера замовлення (якщо передано)
    if "order_id" in parsed and parsed["order_id"] is not None:
        parsed["order_id"] = _normalize_order_id(parsed["order_id"])
    if "sku" in parsed and isinstance(parsed["sku"], str):
        parsed["sku"] = parsed["sku"].strip().upper()

    # Шар 4: валідація за JSON Schema
    schema = TOOL_SCHEMAS[name]["parameters"]
    try:
        jsonschema.validate(instance=parsed, schema=schema)
    except jsonschema.ValidationError as exc:
        reason = f"Аргументи не відповідають схемі: {exc.message}"
        return ToolResult(
            status="rejected",
            reason=reason,
            arguments=parsed,
            content={"error": "schema_validation_failed", "message": reason},
        )

    # Шар 5: виконання з перевіркою власника та обробкою помилок сервісу
    handler = HANDLERS[name]
    try:
        data = handler(parsed, ctx)
        return ToolResult(status="ok", content=data, arguments=parsed)
    except PermissionError as exc:
        reason = str(exc)
        return ToolResult(
            status="rejected",
            reason=reason,
            arguments=parsed,
            content={"error": "access_denied", "message": reason},
        )
    except service.Unavailable as exc:
        reason = str(exc)
        return ToolResult(
            status="error",
            reason=reason,
            arguments=parsed,
            content={
                "error": "service_unavailable",
                "message": "Сервіс магазину тимчасово недоступний. Дані зараз не вдалося отримати.",
            },
        )
    except service.ShopError as exc:
        reason = f"[{exc.code}] {exc}"
        return ToolResult(
            status="error",
            reason=reason,
            arguments=parsed,
            content={"error": exc.code, "message": str(exc)},
        )
    except Exception as exc:
        reason = f"Внутрішня помилка інструмента: {type(exc).__name__}"
        return ToolResult(
            status="error",
            reason=reason,
            arguments=parsed,
            content={"error": "tool_internal_error", "message": "Не вдалося виконати операцію."},
        )

"""Цикл помічника: від питання клієнта до відповіді, спертої на дані магазину."""

from dataclasses import dataclass, field
import json
import os
import time

from dotenv import load_dotenv

from . import llm, tools

load_dotenv()

MAX_ROUNDS = int(os.getenv("TOOL_MAX_ROUNDS", "3"))


@dataclass
class ToolTrace:
    """Запис про один виклик інструмента для журналу та UI."""

    round: int
    name: str
    arguments: str
    status: str
    reason: str | None = None
    result: dict | list | str | None = None
    elapsed: float | None = None


@dataclass
class Answer:
    """Результат циклу обробки питання клієнта."""

    text: str
    calls: list[ToolTrace] = field(default_factory=list)
    rounds: int = 0
    stopped: str = "answer"  # "answer" | "limit"
    model: str | None = None
    elapsed: dict = field(default_factory=dict)
    usage: dict | None = None


def answer(question: str, customer_id: str) -> Answer:
    """Виконати цикл діалогу з моделлю та викликом інструментів у межах MAX_ROUNDS."""
    ctx = tools.Context(customer_id=customer_id)
    messages = llm.build_messages(question)
    tool_specs = tools.specs()

    traces: list[ToolTrace] = []
    model_time = 0.0
    tools_time = 0.0
    total_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    used_model: str | None = None

    rounds_limit = max(1, MAX_ROUNDS)

    for round_idx in range(1, rounds_limit + 1):
        resp = llm.chat(messages=messages, tools=tool_specs, tool_choice="auto")
        used_model = resp.get("model") or used_model
        model_time += resp.get("elapsed", 0.0)

        u = resp.get("usage") or {}
        total_usage["prompt_tokens"] += u.get("prompt_tokens", 0)
        total_usage["completion_tokens"] += u.get("completion_tokens", 0)
        total_usage["total_tokens"] += u.get("total_tokens", 0)

        # Повертаємо повідомлення моделі в історію без спотворення службових полів
        messages.append(resp["message"])

        tool_calls = resp.get("tool_calls") or []
        if not tool_calls:
            return Answer(
                text=resp.get("text", "").strip(),
                calls=traces,
                rounds=round_idx,
                stopped="answer",
                model=used_model,
                elapsed={"model": round(model_time, 3), "tools": round(tools_time, 3)},
                usage=total_usage,
            )

        # Виконуємо кожен запропонований моделлю виклик інструмента
        for tc in tool_calls:
            t0 = time.perf_counter()
            res = tools.call(name=tc["name"], raw_arguments=tc["arguments"], ctx=ctx)
            dt = round(time.perf_counter() - t0, 4)
            tools_time += dt

            traces.append(
                ToolTrace(
                    round=round_idx,
                    name=tc["name"],
                    arguments=tc["arguments"],
                    status=res.status,
                    reason=res.reason,
                    result=res.content,
                    elapsed=dt,
                )
            )

            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc["id"],
                    "content": json.dumps(res.content, ensure_ascii=False),
                }
            )

    # Якщо ліміт звертань вичерпано — робимо фінальний запит без права виклику інструментів,
    # щоб модель сформулювала відповідь із уже зібраних даних
    try:
        final_resp = llm.chat(messages=messages, tools=tool_specs, tool_choice="none")
        model_time += final_resp.get("elapsed", 0.0)
        u = final_resp.get("usage") or {}
        total_usage["prompt_tokens"] += u.get("prompt_tokens", 0)
        total_usage["completion_tokens"] += u.get("completion_tokens", 0)
        total_usage["total_tokens"] += u.get("total_tokens", 0)
        final_text = final_resp.get("text", "").strip()
    except llm.LLMError:
        final_text = ""

    if not final_text:
        final_text = (
            "Вичерпано ліміт звертань для обробки запиту. "
            "Спробуйте уточнити питання або вказати точніший номер замовлення / артикул товару."
        )

    return Answer(
        text=final_text,
        calls=traces,
        rounds=rounds_limit,
        stopped="limit",
        model=used_model,
        elapsed={"model": round(model_time, 3), "tools": round(tools_time, 3)},
        usage=total_usage,
    )

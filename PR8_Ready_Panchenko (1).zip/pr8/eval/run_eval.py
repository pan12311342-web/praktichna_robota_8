"""Скрипт пакетної перевірки помічника на наборі питань eval/questions.json.

Запуск із папки pr8:
    python -m eval.run_eval
"""

import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv
load_dotenv(ROOT / ".env")

from shop import service
from app import assistant


def main() -> None:
    questions_path = Path(__file__).parent / "questions.json"
    questions = json.loads(questions_path.read_text(encoding="utf-8"))

    results = []
    for item in questions:
        service.reset()
        qid = item["id"]
        print(f"[{qid}] ({item['customer']}) {item['question']}")
        try:
            ans = assistant.answer(item["question"], item["customer"])
            record = {
                "id": qid,
                "kind": item["kind"],
                "customer": item["customer"],
                "question": item["question"],
                "expect_tools": item["expect_tools"],
                "expect": item["expect"],
                "actual_tools": [c.name for c in ans.calls],
                "calls": [
                    {
                        "round": c.round,
                        "name": c.name,
                        "arguments": c.arguments,
                        "status": c.status,
                        "reason": c.reason,
                        "result": c.result,
                        "elapsed": c.elapsed,
                    }
                    for c in ans.calls
                ],
                "answer": ans.text,
                "rounds": ans.rounds,
                "stopped": ans.stopped,
                "elapsed": ans.elapsed,
                "usage": ans.usage,
            }
        except Exception as exc:
            record = {
                "id": qid,
                "kind": item["kind"],
                "error": f"{type(exc).__name__}: {exc}",
            }
        results.append(record)

    out_file = Path(__file__).parent / "results.json"
    out_file.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nГотово! Результати збережено у {out_file}")


if __name__ == "__main__":
    main()

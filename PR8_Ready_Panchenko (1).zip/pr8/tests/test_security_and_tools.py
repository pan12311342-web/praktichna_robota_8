"""Автоматичні тести шарів перевірки інструментів (без мережі та API ключа)."""

import json
import pytest
from shop import service
from app import tools


@pytest.fixture(autouse=True)
def reset_shop():
    service.reset()


def test_unknown_tool_rejected():
    res = tools.call("issue_refund", '{"order_id": "10377", "amount": "100"}', tools.Context("C-1002"))
    assert res.status == "rejected"
    assert res.content["error"] == "unknown_tool"


def test_invalid_json_rejected():
    res = tools.call("get_order", "{broken json", tools.Context("C-1001"))
    assert res.status == "rejected"
    assert res.content["error"] == "invalid_json"


def test_schema_validation_rejects_extra_or_invalid_args():
    # Спроба передати customer_id в аргументах заборонена (additionalProperties: false)
    res = tools.call("list_orders", '{"customer_id": "C-1002"}', tools.Context("C-1003"))
    assert res.status == "rejected"
    assert res.content["error"] == "schema_validation_failed"


def test_order_number_normalization():
    res = tools.call("get_order", '{"order_id": "№ 10 458"}', tools.Context("C-1001"))
    assert res.status == "ok"
    assert res.content["order_id"] == "10458"


def test_cross_customer_access_denied():
    # Замовлення 10466 належить C-1002, запитує C-1001
    res = tools.call("get_order", '{"order_id": "10466"}', tools.Context("C-1001"))
    assert res.status == "rejected"
    assert res.content["error"] == "access_denied"


def test_sensitive_fields_sanitized():
    # Власник C-1002 читає замовлення 10466, де є internal_note і card_last4
    res = tools.call("get_order", '{"order_id": "10466"}', tools.Context("C-1002"))
    assert res.status == "ok"
    raw_str = json.dumps(res.content, ensure_ascii=False)
    assert "internal_note" not in res.content
    assert "компенсацію до 200 бонусів" not in raw_str
    assert "8812" not in raw_str
    assert "customer_id" not in res.content


def test_return_policy_enforced():
    # Навушники ORN-X2 у замовленні 10421 не підлягають поверненню як належної якості
    res = tools.call(
        "create_return",
        '{"order_id": "10421", "sku": "ORN-X2", "reason": "not_suitable"}',
        tools.Context("C-1001"),
    )
    assert res.status == "error"
    assert res.content["error"] == "policy"


def test_valid_return_created():
    res = tools.call(
        "create_return",
        '{"order_id": "10412", "sku": "SIR-R10", "reason": "not_suitable"}',
        tools.Context("C-1003"),
    )
    assert res.status == "ok"
    assert res.content["return_id"].startswith("R-")
